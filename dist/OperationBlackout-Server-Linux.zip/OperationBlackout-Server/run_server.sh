#!/usr/bin/env bash
# Launch the headless dedicated server. Extra args are passed through (e.g. --port=7777 --data-dir=/srv/blackout).
DIR="$(cd "$(dirname "$0")" && pwd)"
exec "$DIR/blackout_server.x86_64" --headless -- --server "$@"
