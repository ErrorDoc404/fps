Operation: Blackout - Windows client
Keep OperationBlackout.exe and OperationBlackout.pck in the same folder.
Run OperationBlackout.exe -> JOIN SERVER -> enter the address shown on the server's download page (host:7777).
DEPLOY (SOLO / LOCAL) starts a private local server for solo play.
