Operation: Blackout - Linux ARM64 (aarch64: Ampere, Graviton, Raspberry Pi 4/5) dedicated server
Start:   ./run_server.sh --port=7777 --http-port=8080 --data-dir=./server_data
Players: open http://<server-ip>:8080/ to download the Windows client, then JOIN SERVER <server-ip>:7777.
Firewall: allow UDP 7777 (game) and TCP 8080 (download site). Use --no-web to disable the site.
Files in ./downloads/ (.zip/.7z/.gz/.txt) are offered on the site.
