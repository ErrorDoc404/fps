#!/usr/bin/env bash
# Launch the headless dedicated server. Extra args are passed through (e.g. --port=7777 --http-port=8080).
DIR="$(cd "$(dirname "$0")" && pwd)"
chmod +x "$DIR/blackout_server.arm64" 2>/dev/null || true
cd "$DIR"
exec "$DIR/blackout_server.arm64" --headless -- --server "$@"
